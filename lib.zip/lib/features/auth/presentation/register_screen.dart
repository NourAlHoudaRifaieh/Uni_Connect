import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uni_connect/features/auth/presentation/widgets/academic_info_step.dart';
import 'package:uni_connect/features/auth/presentation/widgets/personal_info_step.dart';
import 'package:uni_connect/core/widgets/auth_header.dart';
import 'package:uni_connect/features/auth/data/auth_repository.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  _RegisterScreenState createState() {
    return _RegisterScreenState();
  }
}

class _RegisterScreenState extends State<RegisterScreen> {

  final PageController _pageController = PageController();
  int _currentStep = 0;

  final _formKeyStep1 = GlobalKey<FormState>();
  final _fullNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  final _authRepository = AuthRepository();

  // String? _selectedFaculty;
  String? _selectedDepartment;
  String? _selectedYear;
  String? _selectedMajor;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    _pageController.dispose();
    _fullNameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
  }

  bool get _isAminEmail =>
      _emailController.text.trim().toLowerCase().endsWith('@admin.ul.edu.lb');

  Future <void> _goToStep2() async{
    if(!_formKeyStep1.currentState!.validate()) return;
    if(_isAminEmail){
      // this for to skip the academic information
      await _handleAdminCreateAccount();
      return;
    }
    setState(() {
      _currentStep = 1;
    });
    _pageController.nextPage(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
    );
  }

  Future<void> _handleAdminCreateAccount() async {
    setState(() => _isLoading = true);

    final error = await _authRepository.register(
      fullName: _fullNameController.text.trim(),
      email: _emailController.text.trim(),
      password: _passwordController.text,
      // faculty and academicYear left null for admins
    );

    if (!mounted) return;
    setState(() => _isLoading = false);

    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error), backgroundColor: Colors.red),
      );
    } else {
      context.go('/login'); // later this becomes '/admin-dashboard'
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Admin account created successfully! Please sign in.'),
            backgroundColor: Colors.green,
        ),
      );
    }
  }

  void _goBackToStep1(){
    setState(() {
      _currentStep = 0;
    });
    _pageController.previousPage(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  // void _handleCreateAccount() async {
  //   if(_selectedFaculty == null || _selectedYear == null || _selectedMajor == null) return;
  //     setState(() {
  //       _isLoading = true;
  //     });
  //     final error = await _authRepository.register(
  //       fullName: _fullNameController.text.trim(),
  //       email: _emailController.text.trim(),
  //       password: _passwordController.text,
  //       faculty: _selectedFaculty!,
  //       academicYear: _selectedYear!,
  //       major: _selectedMajor!,
  //     );
  //     if(!mounted) return;
  //     setState(() {
  //       _isLoading = false;
  //     });
  //     if(error != null){
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         SnackBar(
  //           content: Text(error),
  //           backgroundColor: Colors.red
  //         ),
  //       );
  //     }else{
  //       // direct navigation to login
  //       context.go('/login');
  //       //welcome notification snackbar
  //       ScaffoldMessenger.of(context).showSnackBar(
  //         const SnackBar(
  //           content: Text('Account created successfully! Please sign in.'),
  //           backgroundColor:  Colors.green,
  //         ),
  //       );
  //     }
  //
  //   //Firebase Auth + Firestore logic goes here next
  //   // print('Name: ${_fullNameController.text}');
  //   // print('Email: ${_emailController.text}');
  //   // print('Faculty: ${_selectedFaculty}');
  //   // print('Auto-assigned group: $_selectedFaculty - $_selectedYear');
  // }

  void _handleCreateAccount() async{
    if(_selectedDepartment == null || _selectedYear == null) return;
    bool isBusiness = _selectedDepartment == 'Business Administration';
    bool isYearOne = _selectedYear == 'Year 1';

    if(isBusiness && !isYearOne && _selectedMajor == null){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please select your major for Business Administration.',),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }
    setState(() {
      _isLoading = true;
    });

    String? finalMajor = _selectedMajor;
    if(isBusiness && isYearOne){
      finalMajor = ' Common Core';
    }

    final error = await _authRepository.register(
        fullName: _fullNameController.text.trim(),
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      department: _selectedDepartment,
      academicYear: _selectedYear,
      major: finalMajor,
    );

    if(!mounted) return;
    setState(() {
      _isLoading = false;
    });

    if(error != null){
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text( error, style: GoogleFonts.inter(color: Colors.white,)),
        backgroundColor:  Colors.red,),
      );
    }else {
      context.go('/login');
      ScaffoldMessenger.of(context).showSnackBar(
       SnackBar(
          content: Text('Account created successfully! Please sign in.'),
          backgroundColor:  Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      backgroundColor: Colors.white,
      body:Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          AuthHeader(
            title: 'Create Account',
            subtitle: 'Join Lebanese University platform',
            backLabel: 'Back to login',
            onBack: () {
              if( _currentStep == 0){
                context.go('/login');
              }else{
                _goBackToStep1();
              }
            },
            progressBar: Row(
              children: [
                Expanded(
                  child: Container(
                    height:4,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(width:6),
                Expanded(
                  child: Container(
                    height:4,
                    decoration: BoxDecoration(
                      color: _currentStep == 1 ? Colors.white : Colors.white38,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: PageView(
              controller: _pageController,
              physics: const NeverScrollableScrollPhysics(),
              children: [
                PersonalInfoStep(
                  formKey: _formKeyStep1,
                  fullNameController : _fullNameController,
                  emailController: _emailController,
                  passwordController: _passwordController,
                  onContinue: _goToStep2,
                ),
                AcademicInfoStep(
                  // selectedFaculty: _selectedFaculty,
                  selectedDepartment: _selectedDepartment,
                  selectedMajor: _selectedMajor,
                  selectedYear: _selectedYear,
                  isLoading: _isLoading,
                  // onFacultyChanged: (value) =>
                  //     setState(() => _selectedFaculty = value),
                  onDepartmentChanged: (value) =>
                      setState(() {
                        _selectedDepartment = value;
                        if(value == 'Economic Science'){
                          _selectedMajor = null;
                        }
                      }),
                  onMajorChanged: (value) =>
                      setState(() => _selectedMajor = value),
                  onYearChanged: (value) =>
                      setState(() {
                        _selectedYear = value;
                        if(_selectedDepartment == "Business Administration" && value == "Year 1"){
                          _selectedMajor = null;
                        }
                      }),
                  onBack: _goBackToStep1,
                  onCreateAccount: _handleCreateAccount,
                ),
                // AcademicInfoStep(
                //   selectedFaculty: _selectedFaculty,
                //   selectedYear: _selectedYear,
                //   isLoading: _isLoading,
                //   onFacultyChanged: (value) =>
                //       setState(() => _selectedFaculty = value),
                //   onYearChanged: (value) =>
                //       setState(() => _selectedYear = value),
                //   onBack: _goBackToStep1,
                //   onCreateAccount: _handleCreateAccount,
                // ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}