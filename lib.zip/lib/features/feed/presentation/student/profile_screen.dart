import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uni_connect/features/auth/data/group_repository.dart';
import 'package:uni_connect/features/auth/data/post_repository.dart';
import 'package:uni_connect/features/auth/data/user_repository.dart';
import 'package:uni_connect/features/feed/presentation/student/post_details_screen.dart';
import 'package:uni_connect/features/feed/presentation/widgets/post_card.dart';

import '../../../../core/models/group_model.dart';
import '../../../../core/models/post_model.dart';
import '../../../../core/models/user_model.dart';
import '../../../auth/data/auth_repository.dart';

class ProfileScreen extends StatefulWidget {
  ProfileScreen({Key? key}) : super(key: key);

  @override
  _ProfileScreenState createState() {
    return _ProfileScreenState();
  }
}

class _ProfileScreenState extends State<ProfileScreen> {

  final UserRepository _userRepository = UserRepository();
  final PostRepository _postRepository = PostRepository();
  final GroupRepository _groupRepository = GroupRepository();

  String _getNameFromEmail(String? email) {
    if (email == null || email.isEmpty) return 'User';
    String emailPrefix = email.split('@').first;
    List<String> parts = emailPrefix.split(RegExp(r'[._-]'));
    return parts.map((p) => p.isNotEmpty ? '${p[0].toUpperCase()}${p.substring(1)}' : '').join(' ');
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = FirebaseAuth.instance.currentUser;
    // TODO: implement build
    return Scaffold(
      backgroundColor: Color(0xFFF8FAFC),
      body: StreamBuilder<UserModel?>(
        stream: _userRepository.watchCurrentUser(),
        builder: (context, snapshot) {
          // Fallback data based on Firebase Auth if stream is loading or empty
          final userModel = snapshot.data;
          final email = currentUser?.email ?? 'user@example.com';
          final fullName = userModel?.fullName?.isNotEmpty == true
              ? userModel!.fullName!
              : _getNameFromEmail(email);

          // final faculty = userModel?.faculty ?? '';
          // final academicYear = userModel?.academicYear ?? '';
          // final departmentText = faculty.isNotEmpty && academicYear.isNotEmpty
          //   ? '$faculty, $academicYear'
          //   : (faculty.isNotEmpty
          //     ? faculty
          //     : (academicYear.isNotEmpty
          //       ? academicYear
          //       : (userModel?.major ?? 'Business Administration, Master 2')));
          final postCount = userModel?.postCount?.toString() ?? '0';

          final initials = userModel?.authorInitials.isNotEmpty == true
              ? userModel!.authorInitials
              : (fullName.isNotEmpty ? fullName[0].toUpperCase() : 'U');

          return SingleChildScrollView(
            child: Column(
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 70),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Color(0xFF2563EB), Color(0xFF1E40AF)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              if(context.canPop())
                                GestureDetector(
                                  onTap: () => context.pop(),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.chevron_left_rounded,
                                        color: Colors.white,
                                        size: 24,
                                      ),
                                      SizedBox(width:2),
                                      Text(
                                        'Cancel',
                                        style: GoogleFonts.inter(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              else
                                Text(
                                  'Profile',
                                  style: GoogleFonts.inter(
                                    fontSize: 24,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                  ),
                                ),
                              InkWell(
                                onTap: ()async{
                                  // onPressed: () async{
                                  await AuthRepository().logout();
                                  final prefs = await SharedPreferences.getInstance();
                                  await prefs.remove('remember_me');
                                  await prefs.remove('saved_email');
                                  if(context.mounted){
                                    context.go('/login');
                                  }
                                  // },
                                },
                                borderRadius: BorderRadius.circular(20),
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 14,
                                      vertical: 6
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Row(
                                    children: [
                                      Icon(
                                        Icons.logout,
                                        color: Colors.white,
                                        size:16,
                                      ),
                                      SizedBox(width:6),
                                      Text(
                                        'Sign Out',
                                        style: GoogleFonts.inter(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 13,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height:20),
                          Row(
                            children: [
                              Container(
                                width: 64,
                                height:64,
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.3),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Center(
                                  child: Text(
                                    // 'NR',
                                    initials,
                                    style: GoogleFonts.inter(
                                      color: Colors.white,
                                      fontWeight:FontWeight.bold,
                                      fontSize: 28,
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(width:16),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    // 'Nour Rifaieh',
                                    fullName.isNotEmpty ? fullName : 'UnKnown',
                                    style: GoogleFonts.inter(
                                      fontSize:20,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.white,
                                    ),
                                  ),
                                  SizedBox(height:2),
                                  Text(
                                    email,
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      color: Colors.white.withOpacity(0.8),
                                    ),
                                  ),
                                  SizedBox(height:6),
                                  FutureBuilder<GroupModel?>(
                                      future: userModel?.groupId != null && userModel!.groupId!.isNotEmpty
                                        ? _groupRepository.getGroupById(userModel.groupId!)
                                        : Future.value(null),
                                      builder: (context, groupSnapshot){
                                        final group = groupSnapshot.data;
                                        final academicYearText = group?.academicYear ?? 'Master 2';
                                        return Container(
                                          padding: EdgeInsets.symmetric(
                                            horizontal: 18,
                                            vertical: 3,
                                          ),
                                          decoration: BoxDecoration(
                                            color: Colors.white.withOpacity(0.25),
                                            borderRadius:   BorderRadius.circular(12),
                                          ),
                                          child: Text(
                                            academicYearText,
                                            style: GoogleFonts.inter(
                                              color: Colors.white,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        );
                                      }
                                  ),
                                  // Container(
                                  //   padding: EdgeInsets.symmetric(
                                  //     horizontal: 18,
                                  //     vertical: 3,
                                  //   ),
                                  //   decoration: BoxDecoration(
                                  //     color: Colors.white.withOpacity(0.25),
                                  //     borderRadius:   BorderRadius.circular(12),
                                  //   ),
                                  //   child: Text(
                                  //     academicYear,
                                  //     style: GoogleFonts.inter(
                                  //       color: Colors.white,
                                  //       fontSize: 11,
                                  //       fontWeight: FontWeight.w600,
                                  //     ),
                                  //   ),
                                  // ),
                                ],
                              ),
                            ],
                          ),
                          SizedBox(height:16),
                          FutureBuilder<GroupModel?>(
                              future: userModel?.groupId != null && userModel!.groupId!.isNotEmpty
                                ? _groupRepository.getGroupById(userModel.groupId!)
                                : Future.value(null),
                              builder: (context, groupSnapshot){
                                final group = groupSnapshot.data;
                                final facultyText = group?.faculty ?? 'Business Administration';
                                return Row(
                                  children: [
                                    Icon(
                                      Icons.business_sharp,
                                      color: Colors.white.withOpacity(0.8),
                                      size: 18,
                                    ),
                                    SizedBox(width:8),
                                    Text(
                                      facultyText,
                                      // user?.faculty ?? 'Business Administration',
                                      style: GoogleFonts.inter(
                                        color: Colors.white.withOpacity(0.9),
                                        fontWeight: FontWeight.w500,
                                        fontSize: 13,
                                      ),
                                    ),
                                  ],
                                );
                              },
                          ),
                          // Row(
                          //   children: [
                          //     Icon(
                          //       Icons.business_sharp,
                          //       color: Colors.white.withOpacity(0.8),
                          //       size: 18,
                          //     ),
                          //     SizedBox(width:8),
                          //     Text(
                          //       faculty,
                          //       // user?.faculty ?? 'Business Administration',
                          //       style: GoogleFonts.inter(
                          //         color: Colors.white.withOpacity(0.9),
                          //         fontWeight: FontWeight.w500,
                          //         fontSize: 13,
                          //       ),
                          //     ),
                          //   ],
                          // ),
                        ],
                      ),
                    ),
                    Positioned(
                      left:20,
                      right:20,
                      bottom:-35,
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.06),
                              blurRadius: 12,
                              offset: Offset(0,4),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            // _buildStatItem("14", 'Posts'),
                            _buildStatItem(postCount, 'Posts'),
                            Container(
                              height: 30,
                              width: 1,
                              color: Colors.grey.shade200,
                            ),
                            _buildStatItem('0', 'Comments'),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 50),
                Container(
                  // padding: EdgeInsets.symmetric(horizontal: 20),
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: (){},
                      icon: Icon(
                        Icons.edit_outlined,
                        size: 18,
                        color: Color(0xFF1E293B),
                      ),
                      label:Text(
                        'Edit Profile',
                        style: GoogleFonts.inter(
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      style: OutlinedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 14),
                        side: BorderSide(color: Colors.grey.shade300),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 24),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Recent Posts',
                        style: GoogleFonts.inter(
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      // TextButton(
                      //   onPressed: (){},
                      //   child: Text(
                      //     'See all',
                      //     style: GoogleFonts.inter(
                      //       fontSize: 13,
                      //       fontWeight: FontWeight.w600,
                      //       color: Color(0xFF2563EB),
                      //     ),
                      //   ),
                      // ),
                    ],
                  ),
                ),
                SizedBox(height: 10),
                StreamBuilder<List<PostModel>>(
                    stream: _postRepository.watchAllPosts(),
                    builder: (context, postSnapshot){
                      if(postSnapshot.connectionState == ConnectionState.waiting){
                        return Padding(
                            padding: EdgeInsets.symmetric(vertical: 20),
                            child: Center(
                              child: CircularProgressIndicator(),
                            ),
                        );
                      }
                      final allPosts = postSnapshot.data ?? [];
                      final userPosts = allPosts.where((post) => post.userId == currentUser?.uid).toList();
                      if(userPosts.isEmpty){
                        return Padding(
                          padding: EdgeInsets.symmetric(vertical: 30),
                          child: Center(
                            child: Text(
                              'No posts yet.',
                              style: GoogleFonts.inter(
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                                color: Colors.grey.shade400,
                              ),
                            ),
                          ),
                        );
                      }
                      return ListView.builder(
                        shrinkWrap: true,
                        physics:  NeverScrollableScrollPhysics(),
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: userPosts.length,
                        itemBuilder: (context, index){
                          final post = userPosts[index];
                          return Padding(
                            padding: EdgeInsets.only(bottom:16),
                            child: PostCard(
                              post: post,
                              onTap: () async{
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => PostDetailsScreen(post: post),
                                  ),
                                );
                                if(mounted){
                                  setState(() {

                                  });
                                };
                              },
                              onLikeTap: () async{
                                if(currentUser == null || post.postId == null) return;
                                final userName = userModel?.fullName.trim().isNotEmpty == true
                                  ? userModel!.fullName.trim()
                                  : 'User';
                                await _postRepository.toggleLike(
                                    post.postId!,
                                    currentUser.uid,
                                    userName,
                                );
                              },
                              onCommentTap: () async{
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => PostDetailsScreen(post: post),
                                  ),
                                );
                                if(mounted){
                                  setState(() {

                                  });
                                }
                              },
                            ),
                          );
                        },
                      );
                    }
                ),
                // Center(
                //   child: Text(
                //     'No posts yet',
                //     style: GoogleFonts.inter(
                //       fontWeight: FontWeight.w500,
                //       fontSize: 15,
                //       color: Colors.grey.shade400,
                //     ),
                //   ),
                // ),
                SizedBox(height:10),
              ],
            ),
          );
        },
      ),
      // body:SingleChildScrollView(
      //   child: Column(
      //     children: [
      //       Stack(
      //         clipBehavior: Clip.none,
      //         children: [
      //           Container(
      //             width: double.infinity,
      //             padding: EdgeInsets.symmetric(horizontal: 20, vertical: 70),
      //             decoration: BoxDecoration(
      //               gradient: LinearGradient(
      //                 colors: [Color(0xFF2563EB), Color(0xFF1E40AF)],
      //                 begin: Alignment.topLeft,
      //                 end: Alignment.bottomRight,
      //               ),
      //             ),
      //             child: Column(
      //               crossAxisAlignment: CrossAxisAlignment.start,
      //               children: [
      //                 Row(
      //                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //                   children: [
      //                     if(context.canPop())
      //                       GestureDetector(
      //                         onTap: () => context.pop(),
      //                         child: Row(
      //                           mainAxisSize: MainAxisSize.min,
      //                           children: [
      //                             Icon(
      //                               Icons.chevron_left_rounded,
      //                               color: Colors.white,
      //                               size: 24,
      //                             ),
      //                             SizedBox(width:2),
      //                             Text(
      //                               'Cancel',
      //                               style: GoogleFonts.inter(
      //                                 color: Colors.white,
      //                                 fontWeight: FontWeight.w500,
      //                                 fontSize: 15,
      //                               ),
      //                             ),
      //                           ],
      //                         ),
      //                       )
      //                     else
      //                       Text(
      //                         'Profile',
      //                         style: GoogleFonts.inter(
      //                           fontSize: 24,
      //                           fontWeight: FontWeight.bold,
      //                           color: Colors.white,
      //                         ),
      //                       ),
      //                     InkWell(
      //                       onTap: ()async{
      //                         // onPressed: () async{
      //                         await AuthRepository().logout();
      //                         final prefs = await SharedPreferences.getInstance();
      //                         await prefs.remove('remember_me');
      //                         await prefs.remove('saved_email');
      //                         if(context.mounted){
      //                           context.go('/login');
      //                         }
      //                         // },
      //                       },
      //                       borderRadius: BorderRadius.circular(20),
      //                       child: Container(
      //                         padding: EdgeInsets.symmetric(
      //                             horizontal: 14,
      //                             vertical: 6
      //                         ),
      //                         decoration: BoxDecoration(
      //                           color: Colors.white.withOpacity(0.2),
      //                           borderRadius: BorderRadius.circular(20),
      //                         ),
      //                         child: Row(
      //                           children: [
      //                             Icon(
      //                               Icons.logout,
      //                               color: Colors.white,
      //                               size:16,
      //                             ),
      //                             SizedBox(width:6),
      //                             Text(
      //                               'Sign Out',
      //                               style: GoogleFonts.inter(
      //                                 color: Colors.white,
      //                                 fontWeight: FontWeight.w600,
      //                                 fontSize: 13,
      //                               ),
      //                             ),
      //                           ],
      //                         ),
      //                       ),
      //                     ),
      //                   ],
      //                 ),
      //                 SizedBox(height:20),
      //                 Row(
      //                   children: [
      //                     Container(
      //                       width: 64,
      //                       height:64,
      //                       decoration: BoxDecoration(
      //                         color: Colors.white.withOpacity(0.3),
      //                         borderRadius: BorderRadius.circular(20),
      //                       ),
      //                       child: Center(
      //                         child: Text(
      //                           'NR',
      //                           style: GoogleFonts.inter(
      //                             color: Colors.white,
      //                             fontWeight:FontWeight.bold,
      //                             fontSize: 28,
      //                           ),
      //                         ),
      //                       ),
      //                     ),
      //                     SizedBox(width:16),
      //                     Column(
      //                       crossAxisAlignment: CrossAxisAlignment.start,
      //                       children: [
      //                         Text(
      //                           'Nour Rifaieh',
      //                           style: GoogleFonts.inter(
      //                             fontSize:20,
      //                             fontWeight: FontWeight.bold,
      //                             color: Colors.white,
      //                           ),
      //                         ),
      //                         SizedBox(height:2),
      //                         Text(
      //                           'nour@st.ul.edu.lb',
      //                           style: GoogleFonts.inter(
      //                             fontSize: 13,
      //                             color: Colors.white.withOpacity(0.8),
      //                           ),
      //                         ),
      //                         SizedBox(height:6),
      //                         Container(
      //                           padding: EdgeInsets.symmetric(
      //                             horizontal: 18,
      //                             vertical: 3,
      //                           ),
      //                           decoration: BoxDecoration(
      //                             color: Colors.white.withOpacity(0.25),
      //                             borderRadius:   BorderRadius.circular(12),
      //                           ),
      //                           child: Text(
      //                             'Master 2',
      //                             style: GoogleFonts.inter(
      //                               color: Colors.white,
      //                               fontSize: 11,
      //                               fontWeight: FontWeight.w600,
      //                             ),
      //                           ),
      //                         ),
      //                       ],
      //                     ),
      //                   ],
      //                 ),
      //                 SizedBox(height:16),
      //                 Row(
      //                   children: [
      //                     Icon(
      //                       Icons.business_sharp,
      //                       color: Colors.white.withOpacity(0.8),
      //                       size: 18,
      //                     ),
      //                     SizedBox(width:8),
      //                     Text(
      //                       'Business Administration',
      //                       style: GoogleFonts.inter(
      //                         color: Colors.white.withOpacity(0.9),
      //                         fontWeight: FontWeight.w500,
      //                         fontSize: 13,
      //                       ),
      //                     ),
      //                   ],
      //                 ),
      //               ],
      //             ),
      //           ),
      //           Positioned(
      //             left:20,
      //             right:20,
      //             bottom:-35,
      //             child: Container(
      //               padding: EdgeInsets.symmetric(vertical: 16),
      //               decoration: BoxDecoration(
      //                 color: Colors.white,
      //                 borderRadius: BorderRadius.circular(16),
      //                 boxShadow: [
      //                   BoxShadow(
      //                     color: Colors.black.withOpacity(0.06),
      //                     blurRadius: 12,
      //                     offset: Offset(0,4),
      //                   ),
      //                 ],
      //               ),
      //               child: Row(
      //                 mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      //                 children: [
      //                   _buildStatItem("14", 'Posts'),
      //                   Container(
      //                     height: 30,
      //                     width: 1,
      //                     color: Colors.grey.shade200,
      //                   ),
      //                   _buildStatItem('32', 'Comments'),
      //                 ],
      //               ),
      //             ),
      //           ),
      //         ],
      //       ),
      //       SizedBox(height: 50),
      //       Container(
      //         // padding: EdgeInsets.symmetric(horizontal: 20),
      //         margin: EdgeInsets.symmetric(horizontal: 20),
      //         decoration: BoxDecoration(
      //           color: Colors.white,
      //           borderRadius: BorderRadius.circular(20),
      //         ),
      //         child: SizedBox(
      //           width: double.infinity,
      //           child: OutlinedButton.icon(
      //             onPressed: (){},
      //             icon: Icon(
      //               Icons.edit_outlined,
      //               size: 18,
      //               color: Color(0xFF1E293B),
      //             ),
      //             label:Text(
      //               'Edit Profile',
      //               style: GoogleFonts.inter(
      //                 fontSize: 15,
      //                 fontWeight: FontWeight.w600,
      //                 color: Color(0xFF1E293B),
      //               ),
      //             ),
      //             style: OutlinedButton.styleFrom(
      //               padding: EdgeInsets.symmetric(vertical: 14),
      //               side: BorderSide(color: Colors.grey.shade300),
      //             ),
      //           ),
      //         ),
      //       ),
      //       SizedBox(height: 24),
      //       Padding(
      //         padding: EdgeInsets.symmetric(horizontal: 20),
      //         child: Row(
      //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //           children: [
      //             Text(
      //               'Recent Posts',
      //               style: GoogleFonts.inter(
      //                 fontWeight: FontWeight.bold,
      //                 fontSize: 18,
      //                 color: Color(0xFF1E293B),
      //               ),
      //             ),
      //             TextButton(
      //               onPressed: (){},
      //               child: Text(
      //                 'See all',
      //                 style: GoogleFonts.inter(
      //                   fontSize: 13,
      //                   fontWeight: FontWeight.w600,
      //                   color: Color(0xFF2563EB),
      //                 ),
      //               ),
      //             ),
      //           ],
      //         ),
      //       ),
      //       SizedBox(height: 40),
      //       Center(
      //         child: Text(
      //           'No posts yet',
      //           style: GoogleFonts.inter(
      //             fontWeight: FontWeight.w500,
      //             fontSize: 15,
      //             color: Colors.grey.shade400,
      //           ),
      //         ),
      //       ),
      //       SizedBox(height:40),
      //     ],
      //   ),
      // ),
    );
  }
}

Widget _buildStatItem(String count, String label){
  return Column(
    children: [
      Text(
        count,
        style: GoogleFonts.inter(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Color(0xFF1E293B),
        ),
      ),
      SizedBox(height:2),
      Text(
        label,
        style: GoogleFonts.inter(
          fontSize: 12,
          color: Colors.grey.shade500,
        ),
      ),
    ],
  );
}