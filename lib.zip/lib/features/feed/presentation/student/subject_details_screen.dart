import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uni_connect/features/auth/data/post_repository.dart';
import 'package:uni_connect/features/feed/presentation/student/post_details_screen.dart';
import 'package:uni_connect/features/feed/presentation/widgets/category_selector.dart';
import 'package:uni_connect/features/feed/presentation/widgets/post_card.dart';
import '../../../../core/mock/mock_data.dart';
import '../../../../core/models/post_model.dart';
import '../../../../core/models/subject_model.dart';

class SubjectDetailsScreen extends StatefulWidget {

  final SubjectModel subject;

  SubjectDetailsScreen({
    super.key,
    required this.subject,
  });

  @override
  State<SubjectDetailsScreen> createState() => _SubjectDetailsScreenState();
}

class _SubjectDetailsScreenState extends State<SubjectDetailsScreen> {
  // List <String> categories = ['All','Exams','General help', 'Programming', 'Assignments', 'Math','Physics'];
  final PostRepository _postRepository = PostRepository();
  String selectedCategory = 'All';

  bool _matchesSubject(PostModel post) {
    final matchesCode = widget.subject.subjectCode.isNotEmpty &&
        post.subjectCode?.trim().toLowerCase() == widget.subject.subjectCode.trim().toLowerCase();

    final matchesId = widget.subject.subjectId != null &&
        widget.subject.subjectId!.isNotEmpty &&
        post.subjectId?.trim().toLowerCase() == widget.subject.subjectId!.trim().toLowerCase();

    return matchesCode || matchesId;
  }

  List<String> _getCategories(List <PostModel> posts) {
    final categorySet = <String>{'All'};
    for(var post in posts){
      if(_matchesSubject(post) && post.categoryName != null && post.categoryName!.trim().isNotEmpty){
        categorySet.add(post.categoryName!.trim());
      }
      // final matchesSubject = post.subjectCode?.trim().toLowerCase() == widget.subject.subjectCode.trim().toLowerCase()
      //     || post.subjectId?.trim().toLowerCase() == widget.subject.subjectId!.trim().toLowerCase(); ;
      // // final matchesSubject = post.subjectCode?.trim().toLowerCase() == widget.subject.subjectCode.trim().toLowerCase();
      // if(matchesSubject && post.categoryName !=null && post.categoryName!.trim().isNotEmpty){
      //   categorySet.add(post.categoryName!.trim());
      // }
    }
    return categorySet.toList();
  }

  // List <PostModel> get posts => MockData.posts;
  List <PostModel> _getFilteredPosts(List<PostModel> posts){
    return posts.where((post){
      final matchesSubject = _matchesSubject(post);
      final matchesCategory = selectedCategory == 'All' ||
        post.categoryName?.trim().toLowerCase() == selectedCategory.trim().toLowerCase();
      return matchesSubject && matchesCategory;
      // final matchesSubject = post.subjectCode?.trim().toLowerCase() ==
      //     widget.subject.subjectCode.trim().toLowerCase() ||
      //     post.subjectId?.trim().toLowerCase() == widget.subject.subjectId!.trim().toLowerCase();
      // // final matchesSubject = post.subjectCode?.trim().toLowerCase() == widget.subject.subjectCode.trim().toLowerCase();
      // final matchesCategory = selectedCategory == 'All' || post.categoryName?.trim().toLowerCase() == selectedCategory.trim().toLowerCase();
      // return matchesSubject && matchesCategory ;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    // final displayedPosts = _filteredPosts;
    return Scaffold(
      backgroundColor: Colors.white,
      body:SafeArea(
        child: StreamBuilder<List<PostModel>>(
            stream: _postRepository.watchAllPosts(),
            builder: (context, snapshot){
              if(!snapshot.hasData && snapshot.connectionState == ConnectionState.waiting){
                return Center(
                  child: CircularProgressIndicator(),
                );
              }

              final allPosts = snapshot.data ?? [];
              final categories = _getCategories(allPosts);
              final displayedPosts = _getFilteredPosts(allPosts);

              if(!categories.contains(selectedCategory)){
                selectedCategory = 'All';
              }

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.all(20),
                    child: Column(
                      children: [
                        GestureDetector(
                          onTap: (){
                            Navigator.pop(context);
                          },
                          child: Row(
                            children: [
                              Icon(Icons.chevron_left, color: Color(0xFF2563EB), size:20),
                              Text('Subjects', style: GoogleFonts.inter(color: Color(0xFF2563EB), fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                        SizedBox(height:15),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Color(0xFF1D61FF).withOpacity(0.12),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(Icons.menu_book, color: Color(0xFF1D61FF), size:20),
                            ),
                            SizedBox(width:10),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.subject.subjectCode ?? '',
                                  style: GoogleFonts.inter(
                                      fontSize: 12,
                                      color: Colors.grey.shade800
                                  ),
                                ),
                                Text( widget.subject.subjectName ?? '',
                                    style: GoogleFonts.inter(fontSize: 18, fontWeight:  FontWeight.bold)
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  CategorySelector(
                      categories: categories,
                      onCategorySelected: (category){
                        setState(() {
                          selectedCategory = category;
                        });
                      },
                      selectedCategory: selectedCategory
                  ),
                  SizedBox(height:10),
                  Expanded(
                    child: displayedPosts.isEmpty
                        ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            width:70,
                            height:70,
                            decoration: BoxDecoration(
                              color: Color(0xFFF3F4F6),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child:  Icon(Icons.article_outlined , size:36, color: Color(0xFF9CA3AF)),
                          ),
                          SizedBox(height:16),
                          Text(
                            selectedCategory =='All' ? "No posts for this subject yet" : " No posts in $selectedCategory",
                            style: GoogleFonts.inter(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF6B7280),
                            ),
                          ),
                        ],
                      ),
                    )
                        : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      itemCount: displayedPosts.length,
                      itemBuilder: (context, index) {
                        final post = displayedPosts[index];
                        return PostCard(
                          post: post,
                          onTap: () async{
                            await Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => PostDetailsScreen(post: post))
                            );
                            if(mounted){
                              setState(() {

                              });
                            }
                            // will open post detail screen later
                          },
                          onLikeTap: (){},
                          onCommentTap: (){},
                        );
                      },
                    ),
                  ),
                ],
              );
            }
        ),
      ),
    );
  }
}
